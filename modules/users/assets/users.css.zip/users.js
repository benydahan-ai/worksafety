/**
 * WorkSafety.io - Users Module JavaScript
 * פונקציונליות מתקדמת למודול ניהול המשתמשים
 * 
 * @version 1.0
 * @date 2025
 */

class UsersModule {
    constructor() {
        this.selectedUsers = new Set();
        this.currentSort = {
            column: 'created_at',
            direction: 'DESC'
        };
        this.filters = {
            search: '',
            role: '',
            status: '',
            company: ''
        };
        
        this.init();
    }
    
    init() {
        this.setupEventListeners();
        this.initializeCheckboxes();
        this.initializeFilters();
        this.initializeSorting();
        this.initializeSearch();
        
        console.log('✅ Users Module initialized');
    }
    
    setupEventListeners() {
        // Checkbox selection
        const selectAllCheckbox = document.getElementById('selectAllCheckbox');
        if (selectAllCheckbox) {
            selectAllCheckbox.addEventListener('change', (e) => {
                this.toggleSelectAll(e.target.checked);
            });
        }
        
        // Individual user checkboxes
        document.querySelectorAll('.user-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', (e) => {
                this.toggleUserSelection(e.target.value, e.target.checked);
            });
        });
        
        // Form validation
        const forms = document.querySelectorAll('.user-form');
        forms.forEach(form => {
            form.addEventListener('submit', (e) => this.handleFormSubmit(e));
        });
        
        // Real-time search
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.addEventListener('input', debounce((e) => {
                this.handleSearch(e.target.value);
            }, 300));
        }
        
        // Filter changes
        document.querySelectorAll('.filters-form select').forEach(select => {
            select.addEventListener('change', () => {
                this.applyFilters();
            });
        });
    }
    
    initializeCheckboxes() {
        // Update select all checkbox state based on current selection
        this.updateSelectAllState();
    }
    
    initializeFilters() {
        // Get current URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        
        this.filters = {
            search: urlParams.get('search') || '',
            role: urlParams.get('role') || '',
            status: urlParams.get('status') || '',
            company: urlParams.get('company') || ''
        };
        
        // Auto-apply filters if any exist
        if (Object.values(this.filters).some(value => value !== '')) {
            this.highlightActiveFilters();
        }
    }
    
    initializeSorting() {
        // Add click handlers to sortable column headers
        document.querySelectorAll('.sortable-header').forEach(header => {
            header.addEventListener('click', (e) => {
                const column = e.target.dataset.sort;
                this.handleSort(column);
            });
        });
    }
    
    initializeSearch() {
        // Add search suggestions
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            this.setupSearchSuggestions(searchInput);
        }
    }
    
    // ===================== User Selection =====================
    
    toggleSelectAll(checked) {
        const userCheckboxes = document.querySelectorAll('.user-checkbox');
        
        userCheckboxes.forEach(checkbox => {
            checkbox.checked = checked;
            this.toggleUserSelection(checkbox.value, checked);
        });
        
        this.updateBulkActionsVisibility();
        this.showSelectionNotification();
    }
    
    toggleUserSelection(userId, selected) {
        if (selected) {
            this.selectedUsers.add(userId);
        } else {
            this.selectedUsers.delete(userId);
        }
        
        this.updateSelectAllState();
        this.updateBulkActionsVisibility();
        this.highlightSelectedRows();
    }
    
    updateSelectAllState() {
        const selectAllCheckbox = document.getElementById('selectAllCheckbox');
        const userCheckboxes = document.querySelectorAll('.user-checkbox');
        const checkedBoxes = document.querySelectorAll('.user-checkbox:checked');
        
        if (selectAllCheckbox) {
            if (checkedBoxes.length === 0) {
                selectAllCheckbox.indeterminate = false;
                selectAllCheckbox.checked = false;
            } else if (checkedBoxes.length === userCheckboxes.length) {
                selectAllCheckbox.indeterminate = false;
                selectAllCheckbox.checked = true;
            } else {
                selectAllCheckbox.indeterminate = true;
                selectAllCheckbox.checked = false;
            }
        }
    }
    
    updateBulkActionsVisibility() {
        const bulkActionsBtn = document.querySelector('[onclick="bulkActions()"]');
        if (bulkActionsBtn) {
            if (this.selectedUsers.size > 0) {
                bulkActionsBtn.style.display = 'inline-flex';
                bulkActionsBtn.innerHTML = `
                    <i class="fas fa-edit"></i>
                    פעולות על ${this.selectedUsers.size} פריטים
                `;
            } else {
                bulkActionsBtn.style.display = 'none';
            }
        }
    }
    
    highlightSelectedRows() {
        document.querySelectorAll('.user-row').forEach(row => {
            const userId = row.dataset.userId;
            if (this.selectedUsers.has(userId)) {
                row.classList.add('selected');
            } else {
                row.classList.remove('selected');
            }
        });
    }
    
    showSelectionNotification() {
        if (this.selectedUsers.size > 0) {
            showNotification(`נבחרו ${this.selectedUsers.size} משתמשים`, 'info', 2000);
        }
    }
    
    // ===================== Filtering & Search =====================
    
    handleSearch(query) {
        this.filters.search = query;
        
        if (query.length >= 2) {
            this.performSearch(query);
        } else if (query.length === 0) {
            this.clearSearchResults();
        }
    }
    
    performSearch(query) {
        // Real-time search implementation
        const params = new URLSearchParams(window.location.search);
        params.set('search', query);
        
        // Update URL without reload for better UX
        const newUrl = `${window.location.pathname}?${params.toString()}`;
        history.replaceState(null, '', newUrl);
        
        // Show loading state
        this.showSearchLoading();
        
        // Debounced search - actual filtering happens on server side
        // This is just for immediate visual feedback
        this.filterTableRows(query);
    }
    
    filterTableRows(query) {
        const rows = document.querySelectorAll('.user-row');
        let visibleCount = 0;
        
        rows.forEach(row => {
            const userName = row.querySelector('.user-name').textContent.toLowerCase();
            const userEmail = row.querySelector('.user-email').textContent.toLowerCase();
            const searchTerm = query.toLowerCase();
            
            if (userName.includes(searchTerm) || userEmail.includes(searchTerm)) {
                row.style.display = '';
                visibleCount++;
            } else {
                row.style.display = 'none';
            }
        });
        
        this.updateSearchResults(visibleCount);
    }
    
    clearSearchResults() {
        document.querySelectorAll('.user-row').forEach(row => {
            row.style.display = '';
        });
        
        const searchResults = document.querySelector('.search-results');
        if (searchResults) {
            searchResults.remove();
        }
    }
    
    showSearchLoading() {
        const searchInput = document.querySelector('.search-input');
        if (searchInput) {
            searchInput.classList.add('loading');
        }
        
        setTimeout(() => {
            if (searchInput) {
                searchInput.classList.remove('loading');
            }
        }, 300);
    }
    
    updateSearchResults(count) {
        let searchResults = document.querySelector('.search-results');
        
        if (!searchResults) {
            searchResults = document.createElement('div');
            searchResults.className = 'search-results';
            const tableContainer = document.querySelector('.table-container');
            tableContainer.parentNode.insertBefore(searchResults, tableContainer);
        }
        
        searchResults.innerHTML = `
            <div class="alert alert-info">
                <i class="fas fa-search"></i>
                נמצאו ${count} תוצאות מתוך ${document.querySelectorAll('.user-row').length} משתמשים
            </div>
        `;
    }
    
    applyFilters() {
        const form = document.querySelector('.filters-form');
        if (form) {
            form.submit();
        }
    }
    
    highlightActiveFilters() {
        document.querySelectorAll('.filter-group').forEach(group => {
            const select = group.querySelector('select');
            const input = group.querySelector('input');
            
            if ((select && select.value) || (input && input.value)) {
                group.classList.add('active-filter');
            } else {
                group.classList.remove('active-filter');
            }
        });
    }
    
    setupSearchSuggestions(searchInput) {
        const suggestions = [
            'מנהל ראשי',
            'מנהל חברה', 
            'קבלן',
            'מנהל בטיחות',
            'מפקח',
            'עובד',
            'פעיל',
            'לא פעיל'
        ];
        
        searchInput.setAttribute('list', 'search-suggestions');
        
        let datalist = document.getElementById('search-suggestions');
        if (!datalist) {
            datalist = document.createElement('datalist');
            datalist.id = 'search-suggestions';
            searchInput.parentNode.appendChild(datalist);
        }
        
        suggestions.forEach(suggestion => {
            const option = document.createElement('option');
            option.value = suggestion;
            datalist.appendChild(option);
        });
    }
    
    // ===================== Sorting =====================
    
    handleSort(column) {
        if (this.currentSort.column === column) {
            // Toggle direction
            this.currentSort.direction = this.currentSort.direction === 'ASC' ? 'DESC' : 'ASC';
        } else {
            // New column
            this.currentSort.column = column;
            this.currentSort.direction = 'ASC';
        }
        
        this.updateSortParams();
        this.applySorting();
    }
    
    updateSortParams() {
        const params = new URLSearchParams(window.location.search);
        params.set('sort', this.currentSort.column);
        params.set('order', this.currentSort.direction);
        
        const newUrl = `${window.location.pathname}?${params.toString()}`;
        window.location.href = newUrl;
    }
    
    applySorting() {
        // Update UI to show current sort
        document.querySelectorAll('.sortable-header').forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
            
            if (header.dataset.sort === this.currentSort.column) {
                header.classList.add(`sort-${this.currentSort.direction.toLowerCase()}`);
            }
        });
    }
    
    // ===================== Form Handling =====================
    
    handleFormSubmit(e) {
        const form = e.target;
        
        if (!this.validateForm(form)) {
            e.preventDefault();
            return false;
        }
        
        this.showFormLoading(form);
        return true;
    }
    
    validateForm(form) {
        const errors = [];
        
        // Email validation
        const emailInput = form.querySelector('input[name="email"]');
        if (emailInput && emailInput.value) {
            if (!this.isValidEmail(emailInput.value)) {
                errors.push('כתובת אימייל לא תקינה');
                this.highlightFieldError(emailInput);
            }
        }
        
        // Password validation
        const passwordInput = form.querySelector('input[name="password"]');
        const confirmPasswordInput = form.querySelector('input[name="confirm_password"]');
        
        if (passwordInput && passwordInput.value) {
            if (passwordInput.value.length < 8) {
                errors.push('הסיסמה חייבת להכיל לפחות 8 תווים');
                this.highlightFieldError(passwordInput);
            }
            
            if (confirmPasswordInput && passwordInput.value !== confirmPasswordInput.value) {
                errors.push('אישור הסיסמה לא תואם');
                this.highlightFieldError(confirmPasswordInput);
            }
        }
        
        // Phone validation
        const phoneInput = form.querySelector('input[name="phone"]');
        if (phoneInput && phoneInput.value) {
            if (!this.isValidPhone(phoneInput.value)) {
                errors.push('מספר טלפון לא תקין');
                this.highlightFieldError(phoneInput);
            }
        }
        
        if (errors.length > 0) {
            this.showValidationErrors(errors);
            return false;
        }
        
        return true;
    }
    
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    isValidPhone(phone) {
        const phoneRegex = /^[\d\-\+\(\)\s]+$/;
        const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
        return phoneRegex.test(phone) && cleanPhone.length >= 9;
    }
    
    highlightFieldError(field) {
        field.classList.add('error');
        field.addEventListener('input', () => {
            field.classList.remove('error');
        }, { once: true });
    }
    
    showValidationErrors(errors) {
        let errorContainer = document.querySelector('.validation-errors');
        
        if (!errorContainer) {
            errorContainer = document.createElement('div');
            errorContainer.className = 'alert alert-danger validation-errors';
            
            const form = document.querySelector('.user-form');
            form.parentNode.insertBefore(errorContainer, form);
        }
        
        errorContainer.innerHTML = `
            <div class="alert-icon">
                <i class="fas fa-exclamation-triangle"></i>
            </div>
            <div class="alert-content">
                <div class="alert-title">שגיאות בטופס</div>
                <ul class="error-list">
                    ${errors.map(error => `<li>${error}</li>`).join('')}
                </ul>
            </div>
        `;
        
        errorContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
    
    showFormLoading(form) {
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) {
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> שומר...';
            
            // Store original text for potential restoration
            submitBtn.dataset.originalText = originalText;
        }
    }
    
    // ===================== User Actions =====================
    
    exportUsers() {
        const selectedIds = Array.from(this.selectedUsers);
        const params = new URLSearchParams(window.location.search);
        
        if (selectedIds.length > 0) {
            params.set('export_users', selectedIds.join(','));
        } else {
            params.set('export_all', '1');
        }
        
        const exportUrl = `api/export.php?${params.toString()}`;
        
        // Create temporary link for download
        const link = document.createElement('a');
        link.href = exportUrl;
        link.download = `users_export_${new Date().toISOString().split('T')[0]}.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        showNotification('ייצוא המשתמשים התחיל', 'success');
    }
    
    bulkActions() {
        if (this.selectedUsers.size === 0) {
            showNotification('נא לבחור משתמשים לפני ביצוע פעולות', 'warning');
            return;
        }
        
        this.showBulkActionsModal();
    }
    
    showBulkActionsModal() {
        const modal = this.createBulkActionsModal();
        document.body.appendChild(modal);
        
        // Show modal with animation
        setTimeout(() => {
            modal.classList.add('show');
        }, 10);
    }
    
    createBulkActionsModal() {
        const modal = document.createElement('div');
        modal.className = 'modal bulk-actions-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>פעולות על ${this.selectedUsers.size} משתמשים</h3>
                    <button class="modal-close" onclick="this.closest('.modal').remove()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="bulk-actions-grid">
                        <button class="bulk-action-btn" onclick="usersModule.bulkChangeStatus('active')">
                            <i class="fas fa-user-check"></i>
                            הפעל משתמשים
                        </button>
                        <button class="bulk-action-btn" onclick="usersModule.bulkChangeStatus('inactive')">
                            <i class="fas fa-user-times"></i>
                            השבת משתמשים
                        </button>
                        <button class="bulk-action-btn" onclick="usersModule.bulkExport()">
                            <i class="fas fa-download"></i>
                            ייצא לאקסל
                        </button>
                        <button class="bulk-action-btn danger" onclick="usersModule.bulkDelete()">
                            <i class="fas fa-trash"></i>
                            מחק משתמשים
                        </button>
                    </div>
                </div>
            </div>
        `;
        
        return modal;
    }
    
    bulkChangeStatus(status) {
        const statusNames = {
            'active': 'הפעלת',
            'inactive': 'השבתת',
            'suspended': 'השעיית'
        };
        
        const action = statusNames[status] || 'שינוי סטטוס';
        
        if (confirm(`האם אתה בטוח שברצונך לבצע ${action} של ${this.selectedUsers.size} משתמשים?`)) {
            this.performBulkAction('change_status', { status, users: Array.from(this.selectedUsers) });
        }
    }
    
    bulkDelete() {
        if (confirm(`האם אתה בטוח שברצונך למחוק ${this.selectedUsers.size} משתמשים? פעולה זו אינה ניתנת לביטול!`)) {
            this.performBulkAction('delete', { users: Array.from(this.selectedUsers) });
        }
    }
    
    bulkExport() {
        this.exportUsers();
        document.querySelector('.bulk-actions-modal').remove();
    }
    
    performBulkAction(action, data) {
        fetch('api/bulk_actions.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ action, data })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showNotification(result.message, 'success');
                location.reload(); // Refresh to show changes
            } else {
                showNotification(result.message || 'שגיאה בביצוע הפעולה', 'error');
            }
        })
        .catch(error => {
            console.error('Bulk action error:', error);
            showNotification('שגיאה בביצוע הפעולה', 'error');
        })
        .finally(() => {
            document.querySelector('.bulk-actions-modal').remove();
        });
    }
    
    // ===================== Individual User Actions =====================
    
    deleteUser(userId) {
        const userRow = document.querySelector(`[data-user-id="${userId}"]`);
        const userName = userRow ? userRow.querySelector('.user-name').textContent : 'המשתמש';
        
        if (confirm(`האם אתה בטוח שברצונך למחוק את ${userName}? פעולה זו אינה ניתנת לביטול!`)) {
            this.performUserAction('delete', userId);
        }
    }
    
    toggleUserStatus(userId) {
        const userRow = document.querySelector(`[data-user-id="${userId}"]`);
        const currentStatus = userRow.querySelector('.status-badge').classList.contains('status-active') ? 'active' : 'inactive';
        const newStatus = currentStatus === 'active' ? 'inactive' : 'active';
        
        this.performUserAction('toggle_status', userId, { status: newStatus });
    }
    
    performUserAction(action, userId, data = {}) {
        fetch('api/user_actions.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify({ action, user_id: userId, ...data })
        })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                showNotification(result.message, 'success');
                
                if (action === 'delete') {
                    // Remove row with animation
                    const userRow = document.querySelector(`[data-user-id="${userId}"]`);
                    if (userRow) {
                        userRow.style.animation = 'fadeOut 0.3s ease';
                        setTimeout(() => userRow.remove(), 300);
                    }
                } else {
                    // Refresh specific row or page
                    location.reload();
                }
            } else {
                showNotification(result.message || 'שגיאה בביצוע הפעולה', 'error');
            }
        })
        .catch(error => {
            console.error('User action error:', error);
            showNotification('שגיאה בביצוע הפעולה', 'error');
        });
    }
}

// ===================== Utility Functions =====================

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function selectAllUsers() {
    const selectAllCheckbox = document.getElementById('selectAllCheckbox');
    if (selectAllCheckbox) {
        selectAllCheckbox.click();
    }
}

function exportUsers() {
    if (window.usersModule) {
        window.usersModule.exportUsers();
    }
}

function bulkActions() {
    if (window.usersModule) {
        window.usersModule.bulkActions();
    }
}

function deleteUser(userId) {
    if (window.usersModule) {
        window.usersModule.deleteUser(userId);
    }
}

function toggleAdvancedFilters() {
    const filtersSection = document.querySelector('.filters-section');
    filtersSection.classList.toggle('advanced-mode');
    
    // Show/hide additional filter options
    const advancedFilters = filtersSection.querySelectorAll('.advanced-filter');
    advancedFilters.forEach(filter => {
        filter.style.display = filter.style.display === 'none' ? 'block' : 'none';
    });
}

// ===================== CSS Animations =====================
const additionalStyles = `
@keyframes fadeOut {
    from { opacity: 1; transform: scale(1); }
    to { opacity: 0; transform: scale(0.95); }
}

.modal {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.modal.show {
    opacity: 1;
}

.modal-content {
    background: white;
    border-radius: var(--radius-lg);
    width: 90%;
    max-width: 600px;
    max-height: 80vh;
    overflow-y: auto;
    transform: translateY(-20px);
    transition: transform 0.3s ease;
}

.modal.show .modal-content {
    transform: translateY(0);
}

.modal-header {
    padding: 1.5rem;
    border-bottom: 1px solid #e2e8f0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-close {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    padding: 0.5rem;
    border-radius: 50%;
    transition: background 0.3s ease;
}

.modal-close:hover {
    background: var(--bg-secondary);
}

.modal-body {
    padding: 1.5rem;
}

.bulk-actions-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.bulk-action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
    padding: 1.5rem;
    border: 2px solid #e2e8f0;
    background: white;
    border-radius: var(--radius-lg);
    cursor: pointer;
    transition: all 0.3s ease;
    text-decoration: none;
    color: var(--text-primary);
}

.bulk-action-btn:hover {
    border-color: var(--primary-color);
    background: var(--bg-secondary);
    transform: translateY(-2px);
}

.bulk-action-btn.danger:hover {
    border-color: var(--danger-color);
    background: #fef2f2;
    color: var(--danger-color);
}

.bulk-action-btn i {
    font-size: 2rem;
}

.active-filter {
    background: #eff6ff;
    border: 2px solid var(--primary-color);
    border-radius: var(--radius-md);
    padding: 0.5rem;
}

.user-row.selected {
    background: #eff6ff !important;
    border: 2px solid var(--primary-color);
}

.form-control.error {
    border-color: var(--danger-color);
    box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
}

.form-control.loading {
    background-image: url("data:image/svg+xml,%3csvg width='20' height='20' viewBox='0 0 50 50' xmlns='http://www.w3.org/2000/svg'%3e%3cpath d='M43.935,25.145c0-10.318-8.364-18.683-18.683-18.683c-10.318,0-18.683,8.365-18.683,18.683h4.068c0-8.071,6.543-14.615,14.615-14.615c8.072,0,14.615,6.543,14.615,14.615H43.935z' fill='%23007bff'%3e%3canimateTransform attributeType='xml' attributeName='transform' type='rotate' values='0 25 25; 360 25 25' dur='0.6s' repeatCount='indefinite'/%3e%3c/path%3e%3c/svg%3e");
    background-repeat: no-repeat;
    background-position: left 10px center;
    padding-left: 40px;
}
`;

// Add additional styles to page
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);

// ===================== Initialize Module =====================
document.addEventListener('DOMContentLoaded', function() {
    window.usersModule = new UsersModule();
});

console.log('✅ Users Module JavaScript loaded');
